
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Chargeur' 
 * Target:  'ST Link' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define RTE_DEVICE_STDPERIPH_ADC
#define RTE_DEVICE_STDPERIPH_DMA
#define RTE_DEVICE_STDPERIPH_FRAMEWORK
#define RTE_DEVICE_STDPERIPH_GPIO
#define RTE_DEVICE_STDPERIPH_RCC
#define RTE_DEVICE_STDPERIPH_TIM

#endif /* RTE_COMPONENTS_H */
