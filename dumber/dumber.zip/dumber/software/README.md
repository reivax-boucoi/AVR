# Software

Dans ce repertoire se trouvent les logiciels pour les differentes parties du projet dumber
- robot: Contient le code source du firmware executé par le robot (STM32 / Keil)
- chargeur: Contient le code executé dans le boitier du chargeur de batterie du robot (STM32 / Keil)
- android: Application android pour le pilotage du robot via un module bluetooth à la place du module XBEE de base sur le robot.
