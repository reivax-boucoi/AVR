#ifndef cmde_usart_H
#define cmde_usart_H

void INIT_SPI(void);
void MAP_pinSpi(void);



#endif 

